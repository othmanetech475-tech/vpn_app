import sys
import os

app_path = sys.argv[1]
build_gradle = os.path.join(app_path, "build.gradle")

if os.path.exists(build_gradle):
    with open(build_gradle, "r", encoding="utf-8") as f:
        content = f.read()

    # تعديل minSdk إلى 21
    content = content.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 21")
    content = content.replace("minSdk = flutter.minSdkVersion", "minSdk = 21")

    # إضافة توافقية Java 8
    if "android {" in content:
        java8_config = """
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = '1.8'
    }
"""
        content = content.replace("android {", "android {" + java8_config)

    # إضافة مكتبة WireGuard Tunnel
    if "dependencies {" in content:
        content = content.replace(
            "dependencies {",
            "dependencies {\n    implementation 'com.wireguard.android:tunnel:1.0.20230427'"
        )

    with open(build_gradle, "w", encoding="utf-8") as f:
        f.write(content)
    print("Gradle patched successfully with WireGuard tunnel dependency!")
else:
    print("build.gradle not found!")
