import sys
import os

app_path = sys.argv[1]
build_gradle = os.path.join(app_path, "build.gradle")

if os.path.exists(build_gradle):
    with open(build_gradle, "r", encoding="utf-8") as f:
        content = f.read()

    content = content.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 21")
    content = content.replace("minSdk = flutter.minSdkVersion", "minSdk = 21")

    with open(build_gradle, "w", encoding="utf-8") as f:
        f.write(content)
    print("Gradle patched successfully!")
else:
    print("build.gradle not found!")
