# Gradle patch helper
print("Patching gradle...")
