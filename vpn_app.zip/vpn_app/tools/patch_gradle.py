"""يضيف مكتبة WireGuard وتفعيل desugaring إلى android/app/build.gradle(.kts)."""
import pathlib
import re
import sys

app = pathlib.Path(sys.argv[1])
kts, groovy = app / "build.gradle.kts", app / "build.gradle"

if kts.exists():
    f, s = kts, kts.read_text()
    if "isCoreLibraryDesugaringEnabled" not in s:
        s, n = re.subn(r"compileOptions\s*\{",
                       "compileOptions {\n        isCoreLibraryDesugaringEnabled = true", s, count=1)
        if n != 1:
            sys.exit("compileOptions block not found in build.gradle.kts")
    s += ('\n\ndependencies {\n'
          '    implementation("com.wireguard.android:tunnel:1.0.20230706")\n'
          '    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")\n'
          '}\n')
elif groovy.exists():
    f, s = groovy, groovy.read_text()
    if "coreLibraryDesugaringEnabled" not in s:
        s, n = re.subn(r"compileOptions\s*\{",
                       "compileOptions {\n        coreLibraryDesugaringEnabled true", s, count=1)
        if n != 1:
            sys.exit("compileOptions block not found in build.gradle")
    s += ("\n\ndependencies {\n"
          "    implementation 'com.wireguard.android:tunnel:1.0.20230706'\n"
          "    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'\n"
          "}\n")
else:
    sys.exit("no app build.gradle(.kts) found")

f.write_text(s)
print("patched", f)
