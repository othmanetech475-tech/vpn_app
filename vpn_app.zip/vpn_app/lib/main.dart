import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'inwi Bypass VPN',
      theme: ThemeData.dark(useMaterial3: true),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const MethodChannel _channel = MethodChannel('com.example.vpn/channel');
  bool _isConnected = false;
  
  final TextEditingController _payloadController = TextEditingController(
    text: 'GET / HTTP/1.1[crlf]Host: 3g.inwi.ma[crlf][crlf]'
  );
  final TextEditingController _sniController = TextEditingController(
    text: '3g.inwi.ma'
  );

  Future<void> _toggleVpn() async {
    try {
      if (_isConnected) {
        await _channel.invokeMethod('stop');
        setState(() => _isConnected = false);
      } else {
        final bool? prepared = await _channel.invokeMethod('prepare');
        if (prepared == true) {
          await _channel.invokeMethod('start', {
            'payload': _payloadController.text,
            'sni': _sniController.text,
          });
          setState(() => _isConnected = true);
        }
      }
    } catch (e) {
      debugPrint('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أداة تجاوز inwi مع الحقن الحقيقي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 20),
            GestureDetector(
              onTap: _toggleVpn,
              child: Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isConnected ? Colors.green.shade700 : Colors.blueGrey.shade800,
                  boxShadow: [
                    BoxShadow(
                      color: (_isConnected ? Colors.green : Colors.blue).withOpacity(0.4),
                      blurRadius: 15,
                      spreadRadius: 3,
                    )
                  ],
                ),
                child: Icon(
                  _isConnected ? Icons.power_settings_new : Icons.power_off,
                  size: 70,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              _isConnected ? 'متصل وحقن الحزم فعال' : 'غير متصل',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: _isConnected ? Colors.greenAccent : Colors.white70),
            ),
            const SizedBox(height: 30),
            TextField(
              controller: _sniController,
              decoration: const InputDecoration(
                labelText: 'SNI / Host',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _payloadController,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Payload (الحمولة)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
