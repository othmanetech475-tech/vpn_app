import 'package:flutter/material.dart';
import 'core/constants/app_constants.dart';
import 'core/services/app_state.dart';
import 'core/services/storage_service.dart';
import 'core/services/vpn_service.dart';
import 'core/theme/app_theme.dart';
import 'features/root_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState(VpnService(), StorageService());
  await state.init();
  runApp(VpnApp(state: state));
}

class VpnApp extends StatelessWidget {
  const VpnApp({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: ThemeMode.system,
        builder: (context, child) =>
            Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const RootShell(),
      ),
    );
  }
}
