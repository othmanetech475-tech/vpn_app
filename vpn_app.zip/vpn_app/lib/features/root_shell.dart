import 'package:flutter/material.dart';
import 'home/screens/home_screen.dart';
import 'logs/screens/log_viewer_screen.dart';
import 'servers/screens/server_list_screen.dart';
import 'settings/screens/settings_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});
  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _i = 0;
  static const _pages = [
    HomeScreen(),
    ServerListScreen(),
    LogViewerScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _i, children: _pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.public), label: 'السيرفرات'),
          NavigationDestination(icon: Icon(Icons.terminal), label: 'السجلات'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
