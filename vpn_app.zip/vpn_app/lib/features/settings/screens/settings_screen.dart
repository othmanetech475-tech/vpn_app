import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('الإعدادات', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 16),
        const Text('نمط الاتصال'),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'stable', label: Text('Stable'), icon: Icon(Icons.anchor)),
            ButtonSegment(value: 'speed', label: Text('Speed'), icon: Icon(Icons.bolt)),
          ],
          selected: {s.mode},
          onSelectionChanged: (v) => s.setMode(v.first),
        ),
        const SizedBox(height: 8),
        Text(
          s.mode == 'speed'
              ? 'Speed: إعداد Speed للسيرفر إن وُجد، وإلا MTU 1420.\nتبديل النمط أثناء الاتصال يعيد الاتصال تلقائياً.'
              : 'Stable: MTU 1280 وPersistentKeepalive 25 (إن لم يحددهما الإعداد) لثبات أفضل.\nتبديل النمط أثناء الاتصال يعيد الاتصال تلقائياً.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 24),
        const ListTile(
          leading: Icon(Icons.info_outline),
          title: Text('VPN App'),
          subtitle: Text('الإصدار 0.2.0 • محرك WireGuard (GoBackend)'),
        ),
      ],
    );
  }
}
