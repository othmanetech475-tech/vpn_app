import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';

class StatusCard extends StatelessWidget {
  const StatusCard({super.key, required this.state});
  final AppState state;

  String _fmt(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
  }

  String _speed(double kbps) => kbps >= 1000
      ? '${(kbps / 1000).toStringAsFixed(1)} Mb/s'
      : '${kbps.toStringAsFixed(0)} Kb/s';

  String _bytes(int b) {
    if (b >= 1024 * 1024) return '${(b / 1048576).toStringAsFixed(1)} MB';
    if (b >= 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    return '$b B';
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _row(Icons.dns_outlined, 'السيرفر', state.selected?.name ?? '-'),
            const Divider(),
            _row(Icons.tune, 'النمط', state.modeLabel),
            const Divider(),
            _row(Icons.public, 'IP العام', state.publicIp),
            const Divider(),
            _row(Icons.timer_outlined, 'المدة', _fmt(state.elapsed)),
            const Divider(),
            _row(Icons.arrow_downward, 'تنزيل',
                '${_speed(state.downKbps)}  •  ${_bytes(state.totalRx)}'),
            const Divider(),
            _row(Icons.arrow_upward, 'رفع',
                '${_speed(state.upKbps)}  •  ${_bytes(state.totalTx)}'),
          ],
        ),
      ),
    );
  }

  Widget _row(IconData icon, String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Icon(icon, size: 20),
          const SizedBox(width: 12),
          Text(k),
          const Spacer(),
          Flexible(
            child: Text(
              v,
              textDirection: TextDirection.ltr,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ]),
      );
}
