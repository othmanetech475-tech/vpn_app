import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';

class StatusCard extends StatelessWidget {
  const StatusCard({super.key, required this.state});
  final AppState state;

  String _fmt(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
  }

  String _speed(double kbps) => kbps >= 1000
      ? '${(kbps / 1000).toStringAsFixed(1)} Mb/s'
      : '${kbps.toStringAsFixed(0)} Kb/s';

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _row(Icons.public, 'السيرفر', '${state.selected.flag} ${state.selected.name}'),
            const Divider(),
            _row(Icons.timer_outlined, 'المدة', _fmt(state.elapsed)),
            const Divider(),
            _row(Icons.arrow_downward, 'تنزيل', _speed(state.downKbps)),
            const Divider(),
            _row(Icons.arrow_upward, 'رفع', _speed(state.upKbps)),
          ],
        ),
      ),
    );
  }

  Widget _row(IconData icon, String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Icon(icon, size: 20),
          const SizedBox(width: 12),
          Text(k),
          const Spacer(),
          Text(v, style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      );
}
