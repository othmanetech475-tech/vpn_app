import 'package:flutter/material.dart';
import '../../../models/vpn_status.dart';

class ConnectButton extends StatelessWidget {
  const ConnectButton({super.key, required this.status, required this.onTap});
  final VpnStatus status;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final connected = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final color = connected ? cs.primary : cs.surfaceContainerHighest;
    final fg = connected ? cs.onPrimary : cs.onSurfaceVariant;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: 190,
        height: 190,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow: connected
              ? [BoxShadow(color: cs.primary.withValues(alpha: 0.4), blurRadius: 40, spreadRadius: 6)]
              : [],
        ),
        child: Center(
          child: busy
              ? SizedBox(width: 48, height: 48, child: CircularProgressIndicator(color: fg))
              : Icon(Icons.power_settings_new, size: 84, color: fg),
        ),
      ),
    );
  }
}
