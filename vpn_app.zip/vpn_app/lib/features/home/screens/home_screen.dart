import 'package:flutter/material.dart';
import '../../../core/services/vpn_service.dart';
import '../../../models/server_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _status = 'DOWN';
  String _publicIp = '-';
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _checkStatus();
  }

  Future<void> _checkStatus() async {
    final status = await VpnService.getStatus();
    setState(() => _status = status);
    if (status == 'UP') {
      _fetchIp();
    }
  }

  Future<void> _fetchIp() async {
    final info = await VpnService.getPublicIpInfo();
    setState(() {
      _publicIp = info['ip'] ?? '-';
    });
  }

  Future<void> _toggleVpn() async {
    setState(() => _isLoading = true);
    if (_status == 'UP') {
      await VpnService.stopVpn();
    } else {
      final server = ServerModel(
        id: '1',
        name: 'inwi Free Bypass',
        protocol: 'WireGuard',
        config: '''[Interface]
Address = 192.168.6.192/32
DNS = 1.1.1.1,8.8.8.8
PrivateKey = WIjcx3ACRDU/VS5/LR6JiiwrinMvurDk3MWMknZ7128=

[Peer]
PublicKey = b45qaCXop4JG4x5PJE8T3PYAO5Crg5lCYAjlJFRqSSs=
AllowedIPs = 0.0.0.0/0, ::/0
Endpoint = sp3.vpnjantit.com:1024''',
      );
      await VpnService.startVpn(server);
      await _fetchIp();
    }
    await _checkStatus();
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أنفاق inwi الشاملة')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: _toggleVpn,
                child: Container(
                  width: 160,
                  height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _status == 'UP' ? Colors.green.shade700 : Colors.blueGrey.shade800,
                    boxShadow: [
                      BoxShadow(
                        color: (_status == 'UP' ? Colors.green : Colors.blue).withOpacity(0.4),
                        blurRadius: 20,
                        spreadRadius: 5,
                      )
                    ],
                  ),
                  child: Icon(
                    _status == 'UP' ? Icons.power_settings_new : Icons.power_off,
                    size: 80,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              Text(
                _status == 'UP' ? 'متصل الآن' : 'غير متصل',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: _status == 'UP' ? Colors.greenAccent : Colors.white70),
              ),
              const SizedBox(height: 20),
              Card(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('البروتوكول:'), Text('WireGuard')]),
                      const Divider(),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('IP العام:'), Text(_publicIp, style: const TextStyle(fontWeight: FontWeight.bold))]),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
