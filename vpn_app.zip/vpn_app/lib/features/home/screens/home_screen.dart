import 'package:flutter/material.dart';
import '../../../core/services/vpn_service.dart';
import '../../../models/server_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _status = 'DOWN';
  String _publicIp = 'N/A';
  String _country = 'Unknown';
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _checkStatus();
  }

  Future<void> _checkStatus() async {
    final status = await VpnService.getStatus();
    setState(() {
      _status = status;
    });
    if (status == 'UP') {
      _fetchIp();
    }
  }

  Future<void> _fetchIp() async {
    final info = await VpnService.getPublicIpInfo();
    setState(() {
      _publicIp = info['ip'] ?? 'N/A';
      _country = info['country'] ?? 'Unknown';
    });
  }

  Future<void> _toggleVpn() async {
    setState(() => _isLoading = true);
    if (_status == 'UP') {
      await VpnService.stopVpn();
    } else {
      // افتراضي للتجربة
      final dummyServer = ServerModel(
        id: '1',
        name: 'Default Server',
        config: '[Interface]\nPrivateKey = dummy\nAddress = 10.6.0.13/32\n[Peer]\nPublicKey = dummy\nEndpoint = 0.0.0.0:51820',
        mode: 'Stable',
      );
      await VpnService.startVpn(dummyServer);
      await _fetchIp();
    }
    await _checkStatus();
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('WireGuard VPN')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Status: $_status', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              Text('Public IP: $_publicIp ($_country)', style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 40),
              _isLoading
                  ? const CircularProgressIndicator()
                  : ElevatedButton.styleFrom().noContext != null ? ElevatedButton(
                      onPressed: _toggleVpn,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                        backgroundColor: _status == 'UP' ? Colors.red : Colors.green,
                      ),
                      child: Text(_status == 'UP' ? 'Disconnect' : 'Connect', style: const TextStyle(fontSize: 18, color: Colors.white)),
                    ) : ElevatedButton(
                      onPressed: _toggleVpn,
                      child: Text(_status == 'UP' ? 'Disconnect' : 'Connect'),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
