import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';
import '../../../models/vpn_status.dart';
import '../widgets/connect_button.dart';
import '../widgets/status_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SizedBox(height: 16),
        Center(child: ConnectButton(status: s.status, onTap: s.toggle)),
        const SizedBox(height: 24),
        Center(
          child: Text(
            s.status.label,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
        ),
        const SizedBox(height: 4),
        Center(
          child: Text(
            s.status == VpnStatus.connected ? 'اضغط للقطع' : 'اضغط للاتصال',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
        const SizedBox(height: 24),
        StatusCard(state: s),
        const SizedBox(height: 12),
        Text(
          'نسخة تجريبية: السيرفرات والسرعات وهمية، والنفق لا يمرّر بيانات بعد.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}
