import 'package:flutter/material.dart';
class LogViewerScreen extends StatelessWidget {
  const LogViewerScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Logs')), body: const Center(child: Text('Connection Logs & IP Info')));
  }
}
