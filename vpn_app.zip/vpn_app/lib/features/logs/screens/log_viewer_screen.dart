import 'package:flutter/material.dart';
class LogViewerScreen extends StatelessWidget {
  const LogViewerScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سجلات الاتصال')),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Text('[INFO] Backend initialized\n[INFO] Ready for multi-protocol tunneling', style: TextStyle(fontFamily: 'monospace')),
      ),
    );
  }
}
