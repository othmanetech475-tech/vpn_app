import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';
import '../../../models/log_entry.dart';

class LogViewerScreen extends StatelessWidget {
  const LogViewerScreen({super.key});

  Color _color(BuildContext c, LogLevel l) {
    switch (l) {
      case LogLevel.error:
        return Colors.redAccent;
      case LogLevel.warn:
        return Colors.orange;
      case LogLevel.info:
        return Theme.of(c).colorScheme.onSurface;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final items = s.logs.reversed.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 8, 0),
          child: Row(children: [
            Text('السجلات', style: Theme.of(context).textTheme.headlineSmall),
            const Spacer(),
            IconButton(onPressed: s.clearLogs, icon: const Icon(Icons.delete_outline)),
          ]),
        ),
        Expanded(
          child: items.isEmpty
              ? const Center(child: Text('لا توجد سجلات'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final e = items[i];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Text(
                        '[${e.timeText}] ${e.message}',
                        style: TextStyle(fontFamily: 'monospace', fontSize: 13, color: _color(context, e.level)),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
