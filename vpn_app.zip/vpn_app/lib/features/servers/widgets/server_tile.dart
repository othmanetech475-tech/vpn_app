import 'package:flutter/material.dart';
import '../../../models/server_model.dart';

class ServerTile extends StatelessWidget {
  const ServerTile({super.key, required this.server, required this.selected, required this.onTap});
  final ServerModel server;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: onTap,
        leading: Text(server.flag, style: const TextStyle(fontSize: 28)),
        title: Text('${server.country} - ${server.name}'),
        subtitle: Text('${server.protocol} • ${server.ping} ms'),
        trailing: Icon(
          selected ? Icons.check_circle : Icons.radio_button_unchecked,
          color: selected ? Theme.of(context).colorScheme.primary : null,
        ),
      ),
    );
  }
}
