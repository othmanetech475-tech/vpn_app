import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/services/app_state.dart';
import '../../../models/server_model.dart';

const _hint = '''[Interface]
PrivateKey = ...
Address = 10.6.0.13/32
DNS = 1.1.1.1

[Peer]
PublicKey = ...
Endpoint = 203.0.113.10:51820
AllowedIPs = 0.0.0.0/0, ::/0''';

class ProfileEditorScreen extends StatefulWidget {
  const ProfileEditorScreen({super.key, this.existing});
  final ServerModel? existing;

  @override
  State<ProfileEditorScreen> createState() => _ProfileEditorScreenState();
}

class _ProfileEditorScreenState extends State<ProfileEditorScreen> {
  late final TextEditingController _name;
  late final TextEditingController _stable;
  late final TextEditingController _speed;
  String? _error;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _stable = TextEditingController(text: e?.stableConf ?? '');
    _speed = TextEditingController(text: e?.speedConf ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _stable.dispose();
    _speed.dispose();
    super.dispose();
  }

  Future<void> _paste(TextEditingController c) async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (d?.text != null) setState(() => c.text = d!.text!);
  }

  String _clean(String s) => s.replaceAll('\r', '').trim();

  Future<void> _save() async {
    final name = _name.text.trim();
    final stable = _clean(_stable.text);
    final speed = _clean(_speed.text);
    String? err;
    if (name.isEmpty) {
      err = 'اكتب اسماً للسيرفر';
    } else {
      err = ServerModel.validate(stable);
      if (err == null && speed.isNotEmpty) {
        final e2 = ServerModel.validate(speed);
        if (e2 != null) err = 'إعداد Speed: $e2';
      }
    }
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    final model = ServerModel(
      id: widget.existing?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      stableConf: stable,
      speedConf: speed,
    );
    await AppScope.of(context).saveProfile(model);
    if (mounted) Navigator.of(context).pop();
  }

  Widget _confField(String label, TextEditingController c, {bool optional = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          const Spacer(),
          TextButton.icon(
            onPressed: () => _paste(c),
            icon: const Icon(Icons.content_paste, size: 18),
            label: const Text('لصق'),
          ),
        ]),
        TextField(
          controller: c,
          minLines: 6,
          maxLines: 14,
          textDirection: TextDirection.ltr,
          keyboardType: TextInputType.multiline,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
          decoration: InputDecoration(
            border: const OutlineInputBorder(),
            hintText: optional ? 'اختياري - يُشتق من Stable إن تُرك فارغاً' : _hint,
            hintMaxLines: 12,
            hintTextDirection: TextDirection.ltr,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'إضافة سيرفر' : 'تعديل السيرفر'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _name,
            decoration: const InputDecoration(
              labelText: 'اسم السيرفر (مثل SKY)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          _confField('إعداد Stable (WireGuard .conf)', _stable),
          const SizedBox(height: 16),
          _confField('إعداد Speed', _speed, optional: true),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.redAccent)),
          ],
          const SizedBox(height: 16),
          FilledButton(onPressed: _save, child: const Text('حفظ')),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
