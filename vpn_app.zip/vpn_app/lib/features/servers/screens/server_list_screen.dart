import 'package:flutter/material.dart';
class ServerListScreen extends StatelessWidget {
  const ServerListScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة السيرفرات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          ListTile(
            leading: Icon(Icons.security, color: Colors.green),
            title: Text('WireGuard'),
            subtitle: Text('اتصال نفق مشفر فائق السرعة'),
          ),
        ],
      ),
    );
  }
}
