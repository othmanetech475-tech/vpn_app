import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';
import '../../../models/server_model.dart';
import '../widgets/server_tile.dart';
import 'profile_editor_screen.dart';

class ServerListScreen extends StatelessWidget {
  const ServerListScreen({super.key});

  void _open(BuildContext context, {ServerModel? existing}) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ProfileEditorScreen(existing: existing),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          Text('السيرفرات', style: Theme.of(context).textTheme.headlineSmall),
          const Spacer(),
          FilledButton.icon(
            onPressed: () => _open(context),
            icon: const Icon(Icons.add),
            label: const Text('إضافة'),
          ),
        ]),
        const SizedBox(height: 12),
        if (s.profiles.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 48),
            child: Text(
              'لا توجد سيرفرات. اضغط «إضافة» والصق إعداد WireGuard.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        for (final p in s.profiles)
          ServerTile(
            server: p,
            selected: p.id == s.selected?.id,
            onTap: () => s.selectServer(p),
            onEdit: () => _open(context, existing: p),
            onDelete: () => s.deleteProfile(p),
          ),
      ],
    );
  }
}
