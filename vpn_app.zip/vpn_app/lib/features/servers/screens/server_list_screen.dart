import 'package:flutter/material.dart';
class ServerListScreen extends StatelessWidget {
  const ServerListScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Servers')), body: const Center(child: Text('Servers & Modes (Stable / Speed)')));
  }
}
