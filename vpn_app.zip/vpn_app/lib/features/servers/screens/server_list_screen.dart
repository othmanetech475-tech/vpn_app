import 'package:flutter/material.dart';
import '../../../core/services/app_state.dart';
import '../../../models/server_model.dart';
import '../widgets/server_tile.dart';

class ServerListScreen extends StatelessWidget {
  const ServerListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('السيرفرات', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        for (final srv in ServerModel.demo)
          ServerTile(
            server: srv,
            selected: srv.id == s.selected.id,
            onTap: () => s.selectServer(srv),
          ),
      ],
    );
  }
}
