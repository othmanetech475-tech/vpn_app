import 'dart:convert';
import 'package:http/http.dart' as http;

class IpService {
  static Future<Map<String, String>> fetchPublicIp() async {
    try {
      final response = await http.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return {
            'ip': data['ip'] ?? 'Unknown',
            'country': data['country'] ?? 'Unknown',
            'countryCode': data['country_code'] ?? 'XX',
          };
        }
      }
    } catch (_) {}
    return {'ip': 'N/A', 'country': 'Unknown', 'countryCode': 'XX'};
  }
}
