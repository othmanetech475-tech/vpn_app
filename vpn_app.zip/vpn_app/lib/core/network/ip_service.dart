import 'dart:async';
import 'dart:convert';
import 'dart:io';

class PublicIp {
  final String ip;
  final String country;
  const PublicIp(this.ip, this.country);
}

/// يجلب العنوان العام ورمز البلد (يمر عبر النفق عند الاتصال).
class IpService {
  static const _urls = ['https://ipwho.is/', 'https://api.country.is/'];

  Future<PublicIp?> lookup() async {
    for (final url in _urls) {
      final client = HttpClient()
        ..connectionTimeout = const Duration(seconds: 6);
      try {
        final req = await client.getUrl(Uri.parse(url));
        final res = await req.close().timeout(const Duration(seconds: 8));
        final body = await res.transform(utf8.decoder).join();
        final j = jsonDecode(body) as Map<String, dynamic>;
        final ip = (j['ip'] ?? '').toString();
        final cc = (j['country_code'] ?? j['country'] ?? '??').toString();
        if (ip.isNotEmpty) return PublicIp(ip, cc);
      } catch (_) {
        // جرّب الخدمة التالية
      } finally {
        client.close(force: true);
      }
    }
    return null;
  }
}
