class AppConstants {
  static const appName = 'VPN App';
  static const methodChannel = 'vpn/method';
  static const statusChannel = 'vpn/status';
  static const modeStable = 'stable';
  static const modeSpeed = 'speed';
}
