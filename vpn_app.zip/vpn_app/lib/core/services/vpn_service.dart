import '../../models/server_model.dart';
import 'vpn_channel.dart';

/// واجهة التحكم بالنفق (Start / Stop / Events).
class VpnService {
  final _channel = VpnChannel();

  Stream<Map<dynamic, dynamic>> get events => _channel.events;

  Future<bool> start(ServerModel server, String mode) =>
      _channel.start(server.configFor(mode));

  Future<void> stop() => _channel.stop();
}
