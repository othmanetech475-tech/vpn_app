import 'package:flutter/services.dart';
import '../../models/server_model.dart';
import '../network/ip_service.dart';

class VpnService {
  static const MethodChannel _channel = MethodChannel('com.example.vpn/channel');

  static Future<bool> prepareVpn() async {
    try {
      final bool prepared = await _channel.invokeMethod('prepare');
      return prepared;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> startVpn(ServerModel server) async {
    try {
      bool prepared = await prepareVpn();
      if (!prepared) return false;

      final bool started = await _channel.invokeMethod('start', {
        'config': server.config,
        'protocol': server.protocol,
      });
      return started;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> stopVpn() async {
    try {
      return await _channel.invokeMethod('stop');
    } catch (e) {
      return false;
    }
  }

  static Future<String> getStatus() async {
    try {
      return await _channel.invokeMethod('status');
    } catch (e) {
      return 'DOWN';
    }
  }

  static Future<Map<String, String>> getPublicIpInfo() async {
    return await IpService.fetchPublicIp();
  }
}
