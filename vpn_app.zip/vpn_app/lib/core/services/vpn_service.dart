import '../../models/server_model.dart';
import '../../models/vpn_status.dart';
import 'vpn_channel.dart';

/// واجهة التحكم بالنفق (Start / Stop / Status).
class VpnService {
  final _channel = VpnChannel();

  Stream<VpnStatus> get status => _channel.events.map(VpnStatusX.parse);

  // TODO: عند توفر سيرفرات حقيقية مرّر إعدادات [server] للطبقة الأصلية.
  Future<bool> start(ServerModel server, String mode) => _channel.start(mode);

  Future<void> stop() => _channel.stop();
}
