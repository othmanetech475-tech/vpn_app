import 'dart:async';
import 'package:flutter/widgets.dart';
import '../../models/log_entry.dart';
import '../../models/server_model.dart';
import '../../models/vpn_status.dart';
import '../network/ip_service.dart';
import 'storage_service.dart';
import 'vpn_service.dart';

class AppState extends ChangeNotifier {
  AppState(this._vpn, this._storage);

  final VpnService _vpn;
  final StorageService _storage;
  final _ip = IpService();

  VpnStatus status = VpnStatus.disconnected;
  List<ServerModel> profiles = [];
  ServerModel? selected;
  String mode = 'stable';
  final List<LogEntry> logs = [];

  Duration elapsed = Duration.zero;
  double downKbps = 0;
  double upKbps = 0;
  int totalRx = 0;
  int totalTx = 0;
  String publicIp = '-';

  Timer? _timer;
  int _lastRx = 0;
  int _lastTx = 0;
  bool _haveLast = false;

  String get modeLabel => mode == 'speed' ? 'Speed' : 'Stable';

  Future<void> init() async {
    await _storage.init();
    mode = _storage.mode;
    profiles = _storage.profiles;
    final id = _storage.serverId;
    selected = profiles.isEmpty
        ? null
        : profiles.firstWhere((p) => p.id == id, orElse: () => profiles.first);

    _log('Status: Disconnected');
    if (selected != null) {
      _log('Config: ${selected!.name}');
      _log('Local IP: ${selected!.localIp}');
    }
    _vpn.events.listen(_onEvent,
        onError: (e) => _log('Event error: $e', LogLevel.error));
  }

  // ---------------- أحداث النفق ----------------
  void _onEvent(Map<dynamic, dynamic> e) {
    switch (e['type']) {
      case 'status':
        _onStatus(VpnStatusX.parse(e['value'].toString()));
        break;
      case 'log':
        _log(e['msg'].toString(), LogLevel.error);
        notifyListeners();
        break;
      case 'stats':
        _onStats((e['rx'] as num).toInt(), (e['tx'] as num).toInt());
        break;
    }
  }

  void _onStatus(VpnStatus s) {
    final prev = status;
    status = s;
    if (prev != s) _log('Status: ${s.logText}');
    if (s == VpnStatus.connected && prev != VpnStatus.connected) {
      _startTimer();
      _lookupIp();
    } else if (s == VpnStatus.disconnected) {
      _stopTimer();
    }
    notifyListeners();
  }

  void _onStats(int rx, int tx) {
    if (_haveLast) {
      downKbps = (rx - _lastRx) * 8 / 1000;
      upKbps = (tx - _lastTx) * 8 / 1000;
    }
    _lastRx = rx;
    _lastTx = tx;
    _haveLast = true;
    totalRx = rx;
    totalTx = tx;
    notifyListeners();
  }

  Future<void> _lookupIp() async {
    for (var i = 0; i < 4 && status == VpnStatus.connected; i++) {
      await Future.delayed(const Duration(seconds: 2));
      if (status != VpnStatus.connected) return;
      final r = await _ip.lookup();
      if (r != null) {
        publicIp = '${r.ip} (${r.country})';
        _log('Public IP: $publicIp');
        notifyListeners();
        return;
      }
    }
    if (status == VpnStatus.connected) {
      _log('Public IP: unavailable', LogLevel.warn);
      notifyListeners();
    }
  }

  // ---------------- أوامر المستخدم ----------------
  Future<void> toggle() async {
    if (status == VpnStatus.connecting || status == VpnStatus.disconnecting) {
      return;
    }
    if (status == VpnStatus.connected) {
      status = VpnStatus.disconnecting;
      _log('Status: Disconnecting...');
      notifyListeners();
      await _vpn.stop();
      return;
    }
    final p = selected;
    if (p == null) {
      _log('لا يوجد سيرفر. أضف ملف WireGuard من تبويب السيرفرات.', LogLevel.warn);
      notifyListeners();
      return;
    }
    status = VpnStatus.connecting;
    _log('Config: ${p.name}');
    _log('Local IP: ${p.localIp}');
    _log('Mode: $modeLabel');
    _log('Status: Connecting...');
    notifyListeners();
    try {
      final ok = await _vpn.start(p, mode);
      if (!ok) {
        _log('رفض المستخدم إذن VPN', LogLevel.warn);
        status = VpnStatus.disconnected;
        notifyListeners();
      }
    } catch (e) {
      _log('Error: $e', LogLevel.error);
      status = VpnStatus.disconnected;
      notifyListeners();
    }
  }

  Future<void> _reconnect() async {
    await _vpn.stop();
    for (var i = 0; i < 50 && status != VpnStatus.disconnected; i++) {
      await Future.delayed(const Duration(milliseconds: 100));
    }
    await toggle();
  }

  Future<void> selectServer(ServerModel s) async {
    if (selected?.id == s.id) return;
    selected = s;
    await _storage.setServerId(s.id);
    _log('Config: ${s.name}');
    notifyListeners();
    if (status == VpnStatus.connected) await _reconnect();
  }

  Future<void> setMode(String m) async {
    if (m == mode) return;
    mode = m;
    await _storage.setMode(m);
    _log('Mode: $modeLabel');
    notifyListeners();
    if (status == VpnStatus.connected) await _reconnect();
  }

  Future<void> saveProfile(ServerModel p) async {
    final i = profiles.indexWhere((x) => x.id == p.id);
    if (i >= 0) {
      profiles[i] = p;
      if (selected?.id == p.id) selected = p;
    } else {
      profiles.add(p);
    }
    selected ??= p;
    await _storage.saveProfiles(profiles);
    await _storage.setServerId(selected!.id);
    _log('Config saved: ${p.name}');
    notifyListeners();
  }

  Future<void> deleteProfile(ServerModel p) async {
    if (selected?.id == p.id && status == VpnStatus.connected) {
      await _vpn.stop();
    }
    profiles.removeWhere((x) => x.id == p.id);
    if (selected?.id == p.id) {
      selected = profiles.isEmpty ? null : profiles.first;
      if (selected != null) await _storage.setServerId(selected!.id);
    }
    await _storage.saveProfiles(profiles);
    _log('Config deleted: ${p.name}');
    notifyListeners();
  }

  void clearLogs() {
    logs.clear();
    notifyListeners();
  }

  void _log(String msg, [LogLevel level = LogLevel.info]) {
    logs.add(LogEntry(msg, level: level));
    if (logs.length > 500) logs.removeAt(0);
  }

  void _startTimer() {
    _timer?.cancel();
    elapsed = Duration.zero;
    _haveLast = false;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      elapsed += const Duration(seconds: 1);
      notifyListeners();
    });
  }

  void _stopTimer() {
    _timer?.cancel();
    elapsed = Duration.zero;
    downKbps = 0;
    upKbps = 0;
    totalRx = 0;
    totalTx = 0;
    publicIp = '-';
    _haveLast = false;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;
}
