import 'dart:async';
import 'dart:math';
import 'package:flutter/widgets.dart';
import '../../models/log_entry.dart';
import '../../models/server_model.dart';
import '../../models/vpn_status.dart';
import 'storage_service.dart';
import 'vpn_service.dart';

class AppState extends ChangeNotifier {
  AppState(this._vpn, this._storage);

  final VpnService _vpn;
  final StorageService _storage;
  final _rnd = Random();

  VpnStatus status = VpnStatus.disconnected;
  ServerModel selected = ServerModel.demo.first;
  String mode = 'stable';
  final List<LogEntry> logs = [];
  Duration elapsed = Duration.zero;
  double downKbps = 0;
  double upKbps = 0;
  Timer? _timer;

  Future<void> init() async {
    await _storage.init();
    mode = _storage.mode;
    final id = _storage.serverId;
    selected = ServerModel.demo.firstWhere(
      (s) => s.id == id,
      orElse: () => ServerModel.demo.first,
    );
    _vpn.status.listen(_onStatus, onError: (e) => _log('خطأ في قناة الحالة: $e', LogLevel.error));
    _log('تم تشغيل التطبيق');
  }

  void _onStatus(VpnStatus s) {
    final changed = s != status;
    status = s;
    if (changed) _log('الحالة: ${s.label}');
    if (s == VpnStatus.connected) {
      _startTimer();
    } else if (s == VpnStatus.disconnected) {
      _stopTimer();
    }
    notifyListeners();
  }

  Future<void> toggle() async {
    if (status == VpnStatus.connecting || status == VpnStatus.disconnecting) return;
    if (status == VpnStatus.connected) {
      status = VpnStatus.disconnecting;
      notifyListeners();
      await _vpn.stop();
    } else {
      status = VpnStatus.connecting;
      _log('الاتصال بـ ${selected.name} (${selected.protocol}) - وضع ${mode == 'speed' ? 'السرعة' : 'الثبات'}');
      notifyListeners();
      try {
        final ok = await _vpn.start(selected, mode);
        if (!ok) {
          _log('رفض المستخدم إذن VPN', LogLevel.warn);
          status = VpnStatus.disconnected;
          notifyListeners();
        }
      } catch (e) {
        _log('فشل الاتصال: $e', LogLevel.error);
        status = VpnStatus.disconnected;
        notifyListeners();
      }
    }
  }

  Future<void> selectServer(ServerModel s) async {
    selected = s;
    await _storage.setServerId(s.id);
    _log('تم اختيار السيرفر: ${s.name}');
    notifyListeners();
  }

  Future<void> setMode(String m) async {
    mode = m;
    await _storage.setMode(m);
    notifyListeners();
  }

  void clearLogs() {
    logs.clear();
    notifyListeners();
  }

  void _log(String msg, [LogLevel level = LogLevel.info]) {
    logs.add(LogEntry(msg, level: level));
    if (logs.length > 500) logs.removeAt(0);
  }

  // سرعات تجريبية للعرض فقط إلى أن يوجد محرك نفق فعلي.
  void _startTimer() {
    _timer?.cancel();
    elapsed = Duration.zero;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      elapsed += const Duration(seconds: 1);
      downKbps = 800 + _rnd.nextDouble() * 4000;
      upKbps = 200 + _rnd.nextDouble() * 1200;
      notifyListeners();
    });
  }

  void _stopTimer() {
    _timer?.cancel();
    elapsed = Duration.zero;
    downKbps = 0;
    upKbps = 0;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;
}
