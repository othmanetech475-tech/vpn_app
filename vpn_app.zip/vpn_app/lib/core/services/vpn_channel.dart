import 'package:flutter/services.dart';
import '../constants/app_constants.dart';

/// تغليف MethodChannel/EventChannel للتواصل مع كود Kotlin.
class VpnChannel {
  static const _method = MethodChannel(AppConstants.methodChannel);
  static const _events = EventChannel(AppConstants.statusChannel);

  Future<bool> start(String mode) async =>
      (await _method.invokeMethod<bool>('start', {'mode': mode})) ?? false;

  Future<void> stop() => _method.invokeMethod('stop');

  Stream<String> get events =>
      _events.receiveBroadcastStream().map((e) => e.toString());
}
