import 'package:flutter/services.dart';
import '../constants/app_constants.dart';

/// تغليف MethodChannel/EventChannel للتواصل مع كود Kotlin (WireGuard).
class VpnChannel {
  static const _method = MethodChannel(AppConstants.methodChannel);
  static const _events = EventChannel(AppConstants.statusChannel);

  Future<bool> start(String conf) async =>
      (await _method.invokeMethod<bool>('start', {'conf': conf})) ?? false;

  Future<void> stop() => _method.invokeMethod('stop');

  Stream<Map<dynamic, dynamic>> get events =>
      _events.receiveBroadcastStream().map((e) => e as Map<dynamic, dynamic>);
}
