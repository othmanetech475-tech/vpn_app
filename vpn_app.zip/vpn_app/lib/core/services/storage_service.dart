import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/server_model.dart';

class StorageService {
  late SharedPreferences _p;

  Future<void> init() async => _p = await SharedPreferences.getInstance();

  String? get serverId => _p.getString('server_id');
  Future<void> setServerId(String v) => _p.setString('server_id', v);

  String get mode => _p.getString('mode') ?? 'stable';
  Future<void> setMode(String v) => _p.setString('mode', v);

  List<ServerModel> get profiles {
    final raw = _p.getString('profiles');
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((e) => ServerModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveProfiles(List<ServerModel> list) => _p.setString(
      'profiles', jsonEncode(list.map((e) => e.toJson()).toList()));
}
