import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  late SharedPreferences _p;

  Future<void> init() async => _p = await SharedPreferences.getInstance();

  String? get serverId => _p.getString('server_id');
  Future<void> setServerId(String v) => _p.setString('server_id', v);

  String get mode => _p.getString('mode') ?? 'stable';
  Future<void> setMode(String v) => _p.setString('mode', v);
}
