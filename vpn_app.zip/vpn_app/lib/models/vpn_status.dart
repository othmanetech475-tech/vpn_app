enum VpnStatus { disconnected, connecting, connected, disconnecting }

extension VpnStatusX on VpnStatus {
  static VpnStatus parse(String s) {
    switch (s) {
      case 'connecting':
        return VpnStatus.connecting;
      case 'connected':
        return VpnStatus.connected;
      case 'disconnecting':
        return VpnStatus.disconnecting;
      default:
        return VpnStatus.disconnected;
    }
  }

  String get label {
    switch (this) {
      case VpnStatus.connected:
        return 'متصل';
      case VpnStatus.connecting:
        return 'جارٍ الاتصال...';
      case VpnStatus.disconnecting:
        return 'جارٍ قطع الاتصال...';
      case VpnStatus.disconnected:
        return 'غير متصل';
    }
  }
}
