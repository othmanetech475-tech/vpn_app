class ServerModel {
  final String id;
  final String name;
  final String config;
  final String mode; // Stable أو Speed
  final int mtu;
  final int keepAlive;

  ServerModel({
    required this.id,
    required this.name,
    required this.config,
    this.mode = 'Stable',
    this.mtu = 1280,
    this.keepAlive = 25,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'config': config,
        'mode': mode,
        'mtu': mtu,
        'keepAlive': keepAlive,
      };

  factory ServerModel.fromJson(Map<String, dynamic> json) => ServerModel(
        id: json['id'] ?? '',
        name: json['name'] ?? '',
        config: json['config'] ?? '',
        mode: json['mode'] ?? 'Stable',
        mtu: json['mtu'] ?? 1280,
        keepAlive: json['keepAlive'] ?? 25,
      );
}
