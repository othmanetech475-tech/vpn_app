/// ملف سيرفر WireGuard: إعداد "Stable" وإعداد "Speed" اختياري.
/// إن لم يُدخل إعداد Speed يُشتق من إعداد Stable بتغيير MTU.
class ServerModel {
  final String id;
  final String name;
  final String stableConf;
  final String speedConf;

  const ServerModel({
    required this.id,
    required this.name,
    required this.stableConf,
    this.speedConf = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'stable': stableConf,
        'speed': speedConf,
      };

  factory ServerModel.fromJson(Map<String, dynamic> j) => ServerModel(
        id: j['id'] as String,
        name: j['name'] as String,
        stableConf: j['stable'] as String,
        speedConf: (j['speed'] as String?) ?? '',
      );

  static String? _find(String conf, String key) {
    final m = RegExp('^\\s*$key\\s*=\\s*(.+?)\\s*\$',
            multiLine: true, caseSensitive: false)
        .firstMatch(conf);
    return m?.group(1);
  }

  String get endpoint => _find(stableConf, 'Endpoint') ?? '-';

  String get localIp {
    final a = _find(stableConf, 'Address');
    if (a == null) return '-';
    return a.split(',').first.split('/').first.trim();
  }

  /// الإعداد النهائي حسب الوضع.
  String configFor(String mode) {
    final custom = speedConf.trim();
    if (mode == 'speed') {
      if (custom.isNotEmpty) return custom;
      return _addIfMissing(stableConf, 'Interface', 'MTU', '1420');
    }
    var c = _addIfMissing(stableConf, 'Interface', 'MTU', '1280');
    c = _addIfMissing(c, 'Peer', 'PersistentKeepalive', '25');
    return c;
  }

  static String _addIfMissing(
      String conf, String section, String key, String value) {
    final has = RegExp('^\\s*$key\\s*=', multiLine: true, caseSensitive: false);
    if (has.hasMatch(conf)) return conf;
    final lines = conf.split('\n');
    final i = lines
        .indexWhere((l) => l.trim().toLowerCase() == '[${section.toLowerCase()}]');
    if (i < 0) return conf;
    lines.insert(i + 1, '$key = $value');
    return lines.join('\n');
  }

  /// يعيد رسالة خطأ أو null إن كان الإعداد يبدو سليماً.
  static String? validate(String conf) {
    final c = conf.toLowerCase();
    for (final k in [
      '[interface]',
      '[peer]',
      'privatekey',
      'publickey',
      'endpoint',
      'allowedips',
      'address',
    ]) {
      if (!c.contains(k)) return 'الإعداد ناقص: $k';
    }
    return null;
  }
}
