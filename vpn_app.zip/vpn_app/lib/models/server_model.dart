class ServerModel {
  final String id;
  final String name;
  final String protocol;
  final String config;

  ServerModel({
    required this.id,
    required this.name,
    this.protocol = 'WireGuard',
    required this.config,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'protocol': protocol,
        'config': config,
      };

  factory ServerModel.fromJson(Map<String, dynamic> json) => ServerModel(
        id: json['id'] ?? '',
        name: json['name'] ?? '',
        protocol: json['protocol'] ?? 'WireGuard',
        config: json['config'] ?? '',
      );
}
