class ServerModel {
  final String id;
  final String name;
  final String country;
  final String flag;
  final String ip;
  final String protocol;
  final int ping;

  const ServerModel({
    required this.id,
    required this.name,
    required this.country,
    required this.flag,
    required this.ip,
    required this.protocol,
    required this.ping,
  });

  /// سيرفرات تجريبية (وهمية) إلى أن تتوفر سيرفراتك الحقيقية.
  static const demo = <ServerModel>[
    ServerModel(id: 'de1', name: 'برلين', country: 'ألمانيا', flag: '🇩🇪', ip: '203.0.113.10', protocol: 'WireGuard', ping: 48),
    ServerModel(id: 'nl1', name: 'أمستردام', country: 'هولندا', flag: '🇳🇱', ip: '203.0.113.20', protocol: 'WireGuard', ping: 52),
    ServerModel(id: 'fr1', name: 'باريس', country: 'فرنسا', flag: '🇫🇷', ip: '203.0.113.30', protocol: 'WireGuard', ping: 40),
    ServerModel(id: 'us1', name: 'نيويورك', country: 'أمريكا', flag: '🇺🇸', ip: '203.0.113.40', protocol: 'WireGuard', ping: 120),
  ];
}
