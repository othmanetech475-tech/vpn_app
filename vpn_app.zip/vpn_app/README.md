# VPN App
Flutter + Android + WireGuard (GoBackend). يُبنى عبر GitHub Actions.
- مجلد `android/` يُولَّد في الـ CI، وملفاتنا الأصلية في `android_overrides/`.
- `tools/patch_gradle.py` يضيف مكتبة `com.wireguard.android:tunnel`.
- السيرفرات تُضاف من داخل التطبيق بلصق ملف WireGuard `.conf`.
