# VPN App
Flutter + Android VpnService. يُبنى عبر GitHub Actions (`.github/workflows/build.yml`).
مجلد `android/` يُولَّد تلقائياً في الـ CI، وملفاتنا الأصلية في `android_overrides/`.
