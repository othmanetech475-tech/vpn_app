package com.example.vpn

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import io.flutter.plugin.common.EventChannel
import java.io.BufferedReader
import java.io.StringReader
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * يدير نفق WireGuard الحقيقي عبر GoBackend، ويرسل الأحداث إلى Flutter:
 *  {type: status, value: connecting|connected|disconnecting|disconnected}
 *  {type: log,    msg: ...}
 *  {type: stats,  rx: bytes, tx: bytes}
 */
object VpnManager {
    @Volatile var sink: EventChannel.EventSink? = null
    @Volatile var connected = false

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val poller = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "vpn0"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.DOWN && connected) {
                // أُسقط النفق من خارج التطبيق (مثلاً سحب النظام للإذن)
                connected = false
                stopStats()
                status("disconnected")
            }
        }
    }

    private fun emit(m: Map<String, Any>) {
        main.post { sink?.success(m) }
    }

    fun status(s: String) = emit(mapOf("type" to "status", "value" to s))
    fun log(msg: String) = emit(mapOf("type" to "log", "msg" to msg))

    fun currentStatus(): String = if (connected) "connected" else "disconnected"

    fun connect(ctx: Context, conf: String) {
        status("connecting")
        val appCtx = ctx.applicationContext
        worker.execute {
            try {
                val b = backend ?: GoBackend(appCtx).also { backend = it }
                val cfg = Config.parse(BufferedReader(StringReader(conf)))
                b.setState(tunnel, Tunnel.State.UP, cfg)
                connected = true
                status("connected")
                startStats(b)
            } catch (e: Exception) {
                connected = false
                log("Error: ${e.message ?: e.toString()}")
                status("disconnected")
            }
        }
    }

    fun disconnect() {
        status("disconnecting")
        worker.execute {
            try {
                backend?.setState(tunnel, Tunnel.State.DOWN, null)
            } catch (e: Exception) {
                log("Error: ${e.message ?: e.toString()}")
            }
            connected = false
            stopStats()
            status("disconnected")
        }
    }

    private fun startStats(b: GoBackend) {
        stopStats()
        statsTask = poller.scheduleAtFixedRate({
            try {
                val s = b.getStatistics(tunnel)
                emit(mapOf("type" to "stats", "rx" to s.totalRx(), "tx" to s.totalTx()))
            } catch (_: Exception) {
            }
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun stopStats() {
        statsTask?.cancel(false)
        statsTask = null
    }
}
