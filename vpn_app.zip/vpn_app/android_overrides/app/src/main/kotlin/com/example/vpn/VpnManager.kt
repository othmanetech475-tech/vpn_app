package com.example.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.StringReader

class VpnManager(private val context: Context) : Tunnel {
    private var backend: Backend? = null
    private var currentTunnelName: String = "wg0"
    private var state: Tunnel.State = Tunnel.State.DOWN

    init {
        try {
            System.loadLibrary("wg-go")
            backend = GoBackend(context)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getName(): String = currentTunnelName

    override fun onStateChange(newState: Tunnel.State) {
        state = newState
    }

    fun prepare(): Intent? {
        return VpnService.prepare(context)
    }

    @Throws(Exception::class)
    fun startVpn(configString: String) {
        val backendInstance = backend ?: throw IllegalStateException("Backend not initialized")
        val config = Config.parse(StringReader(configString))
        backendInstance.setState(this, Tunnel.State.UP, config)
    }

    @Throws(Exception::class)
    fun stopVpn() {
        val backendInstance = backend ?: throw IllegalStateException("Backend not initialized")
        backendInstance.setState(this, Tunnel.State.DOWN, null)
    }

    fun getState(): String {
        return state.name
    }
}
