package com.example.vpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.channels.SocketChannel
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class VpnManager : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var isRunning = false
    private lateinit var executor: ExecutorService

    override fun onCreate() {
        super.onCreate()
        executor = Executors.newCachedThreadPool()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if ("STOP" == action) {
            disconnectVpn()
            return START_NOT_STICKY
        }
        
        val payload = intent?.getStringExtra("payload") ?: ""
        val sni = intent?.getStringExtra("sni") ?: ""
        
        startVpnTunnel(payload, sni)
        return START_STICKY
    }

    private fun startVpnTunnel(payload: String, sni: String) {
        if (isRunning) return
        try {
            val builder = Builder()
                .addAddress("10.0.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .setSession("inwi Real Tunnel")
                .setMtu(1400)

            vpnInterface = builder.establish()
            isRunning = true

            val pfd = vpnInterface ?: return
            
            executor.submit {
                try {
                    val inputStream = FileInputStream(pfd.fileDescriptor)
                    val outputStream = FileOutputStream(pfd.fileDescriptor)
                    val packet = ByteArray(32767)

                    // تنسيق الـ Payload وحقن الـ SNI
                    val formattedPayload = payload
                        .replace("[crlf]", "\r\n")
                        .replace("[host]", sni)

                    while (isRunning) {
                        val length = inputStream.read(packet)
                        if (length > 0) {
                            // معالجة الحزم وتوجيه الاتصال عبر المقابس المحمية
                            forwardPacketWithPayload(packet, length, sni, formattedPayload)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            isRunning = false
        }
    }

    private fun forwardPacketWithPayload(packet: ByteArray, length: Int, sni: String, payload: String) {
        try {
            if (sni.isEmpty()) return
            
            // فتح قناة مقبس جديدة وتطبيق الحماية لكي تتجاوز النفق الوهمي
            val socketChannel = SocketChannel.open()
            val socket = socketChannel.socket()
            protect(socket)
            
            // الاتصال بنطاق الـ SNI أو الخادم المخصص
            socket.connect(InetSocketAddress(sni, 80), 3000)
            
            if (socket.isConnected && payload.isNotEmpty()) {
                val writer = socket.getOutputStream()
                writer.write(payload.toByteArray(Charsets.UTF_8))
                writer.flush()
            }
            socket.close()
        } catch (e: Exception) {
            // تجاهل أخطاء المهلة المؤقتة أثناء تدفق الحزم
        }
    }

    private fun disconnectVpn() {
        try {
            isRunning = false
            executor.shutdownNow()
            vpnInterface?.close()
            vpnInterface = null
            stopSelf()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectVpn()
    }
}
