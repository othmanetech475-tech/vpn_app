package com.example.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import io.flutter.plugin.common.EventChannel

/**
 * نسخة أولية: تنشئ واجهة TUN حقيقية (تظهر أيقونة المفتاح) لكن بمسار وهمي واحد
 * (10.8.0.1/32) حتى لا يُقطع الإنترنت. عند توفر سيرفرات: ضع محرك WireGuard/sing-box
 * داخل startTunnel() ومرّر الحزم من/إلى واجهة tun.
 */
class VpnServiceImpl : VpnService() {

    companion object {
        const val ACTION_STOP = "com.example.vpn.STOP"
        @Volatile var running = false
        @Volatile var sink: EventChannel.EventSink? = null
        private val main = Handler(Looper.getMainLooper())

        fun emit(state: String) {
            main.post { sink?.success(state) }
        }
    }

    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel()
            stopSelf()
            return START_NOT_STICKY
        }
        val mode = intent?.getStringExtra("mode") ?: "stable"
        startTunnel(mode)
        return START_STICKY
    }

    private fun startTunnel(mode: String) {
        emit("connecting")
        try {
            tun?.close()
            tun = Builder()
                .setSession("VPN App")
                .addAddress("10.8.0.2", 32)
                .addRoute("10.8.0.1", 32)
                .setMtu(if (mode == "speed") 1500 else 1400)
                .establish()
            running = tun != null
        } catch (e: Exception) {
            running = false
        }
        emit(if (running) "connected" else "disconnected")
    }

    private fun stopTunnel() {
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        running = false
        emit("disconnected")
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }
}
