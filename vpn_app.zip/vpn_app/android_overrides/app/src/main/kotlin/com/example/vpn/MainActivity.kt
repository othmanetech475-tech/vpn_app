package com.example.vpn

import android.content.Intent
import android.net.VpnService
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.example.vpn/channel"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "prepare" -> {
                    val intent = VpnService.prepare(context)
                    if (intent != null) {
                        startActivityForResult(intent, 0)
                        result.success(false)
                    } else {
                        result.success(true)
                    }
                }
                "start" -> {
                    val payload = call.argument<String>("payload") ?: ""
                    val sni = call.argument<String>("sni") ?: ""
                    
                    val intent = Intent(this, VpnManager::class.java).apply {
                        putExtra("payload", payload)
                        putExtra("sni", sni)
                    }
                    startService(intent)
                    result.success(true)
                }
                "stop" -> {
                    val intent = Intent(this, VpnManager::class.java).apply {
                        action = "STOP"
                    }
                    startService(intent)
                    result.success(true)
                }
                "status" -> {
                    result.success("UP")
                }
                else -> result.notImplemented()
            }
        }
    }
}
