package com.example.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private var pending: MethodChannel.Result? = null
    private var pendingMode = "stable"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "vpn/method").setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> {
                    pendingMode = call.argument<String>("mode") ?: "stable"
                    val prepare = VpnService.prepare(this)
                    if (prepare != null) {
                        pending = result
                        startActivityForResult(prepare, 100)
                    } else {
                        startVpn()
                        result.success(true)
                    }
                }
                "stop" -> {
                    startService(Intent(this, VpnServiceImpl::class.java).setAction(VpnServiceImpl.ACTION_STOP))
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        EventChannel(messenger, "vpn/status").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, events: EventChannel.EventSink?) {
                VpnServiceImpl.sink = events
                events?.success(if (VpnServiceImpl.running) "connected" else "disconnected")
            }
            override fun onCancel(args: Any?) {
                VpnServiceImpl.sink = null
            }
        })
    }

    private fun startVpn() {
        startService(Intent(this, VpnServiceImpl::class.java).putExtra("mode", pendingMode))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 100) {
            val ok = resultCode == Activity.RESULT_OK
            if (ok) startVpn()
            pending?.success(ok)
            pending = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
