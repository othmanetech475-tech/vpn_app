package com.example.vpn

import android.content.Intent
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.example.vpn/channel"
    private lateinit var vpnManager: VpnManager

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        vpnManager = VpnManager(applicationContext)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "prepare" -> {
                    val intent = vpnManager.prepare()
                    if (intent != null) {
                        startActivityForResult(intent, 0)
                        result.success(false)
                    } else {
                        result.success(true)
                    }
                }
                "start" -> {
                    val config = call.argument<String>("config") ?: ""
                    val protocol = call.argument<String>("protocol") ?: "WireGuard"
                    try {
                        vpnManager.startVpn(config, protocol)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("VPN_START_ERROR", e.message, null)
                    }
                }
                "stop" -> {
                    try {
                        vpnManager.stopVpn()
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("VPN_STOP_ERROR", e.message, null)
                    }
                }
                "status" -> {
                    result.success(vpnManager.getState())
                }
                else -> result.notImplemented()
            }
        }
    }
}
