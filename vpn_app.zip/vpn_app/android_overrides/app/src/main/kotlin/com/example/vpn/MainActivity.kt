package com.example.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private var pending: MethodChannel.Result? = null
    private var pendingConf = ""

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "vpn/method").setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> {
                    val conf = call.argument<String>("conf") ?: ""
                    val prepare = VpnService.prepare(this)
                    if (prepare != null) {
                        pendingConf = conf
                        pending = result
                        startActivityForResult(prepare, 100)
                    } else {
                        VpnManager.connect(this, conf)
                        result.success(true)
                    }
                }
                "stop" -> {
                    VpnManager.disconnect()
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        EventChannel(messenger, "vpn/status").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, events: EventChannel.EventSink?) {
                VpnManager.sink = events
                events?.success(mapOf("type" to "status", "value" to VpnManager.currentStatus()))
            }

            override fun onCancel(args: Any?) {
                VpnManager.sink = null
            }
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 100) {
            val ok = resultCode == Activity.RESULT_OK
            if (ok) VpnManager.connect(this, pendingConf)
            pending?.success(ok)
            pending = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
